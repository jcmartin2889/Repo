/*
 *
 * Sample program for use with the Product
 * Licensed Materials  - Property of IBM
 * 5724-I66
 * (c) Copyright IBM Corp.  2008
 *   
 */
package com.ibm.wbit.tel.client.jsf.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

/**
 * To convert times this conveter is for.
 */
public class TimeConverter extends javax.faces.convert.DateTimeConverter {
	
	
	/**
	 * Constructor
	 */
    public TimeConverter() {
        super();
        setType("time");      
    }
	
	/**
	 * Use exactly the same input provided by user. 
	 */
	public Object getAsObject(FacesContext context, UIComponent component, String value ) {
			
		return value; 
	}
	
}
