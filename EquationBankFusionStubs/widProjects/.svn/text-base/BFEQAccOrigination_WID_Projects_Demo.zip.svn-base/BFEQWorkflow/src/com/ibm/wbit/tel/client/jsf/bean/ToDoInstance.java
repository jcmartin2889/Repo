/*
*
* Sample program for use with the Product
* Licensed Materials  - Property of IBM
* 5724-I66
* (c) Copyright IBM Corp.  2006, 2009
*   
*/
package com.ibm.wbit.tel.client.jsf.bean;

import java.util.HashMap;

import com.ibm.bpc.clientcore.DataObjectUtils;
import com.ibm.bpe.jsf.exception.PropertyNotFoundException;
import com.ibm.bpe.jsf.exception.PropertyPopulationException;
import com.ibm.task.api.QueryResultSet;
import com.ibm.task.clientmodel.HTMConnection;
import com.ibm.task.clientmodel.bean.TaskInstanceBean;
import com.ibm.wbit.tel.client.jsf.infrastructure.SharedConstants;
import commonj.sdo.DataObject;


/**
 * ToDoInstance represents an entry in list open ToDos and under work ToDos. 
 */
public class ToDoInstance extends TaskInstanceBean implements SharedConstants {
	
	private static final long serialVersionUID = 602L;
	
	/**
     * The value map which contains the values of the input message. 
     * Task input messages can be get by JSF pages. 
     */
	private HashMap inputValues = null;
	 
	/**
     * The value map which contains the values for the output message.
     * Task output messages can be set by JSF pages. 
     */
	private HashMap outputValues = null;
    
    
    /**
	 * Constructs a ToDoInstance from a query result set returned by the HumanTaskManager API
	 * 
	 * @param resultSet the query result from a query call; represents a row of this result
	 * @param htmConnection the connection to the Human Task Manager
	 */
    public ToDoInstance(QueryResultSet resultSet, HTMConnection htmConnection) {
        super(resultSet, htmConnection);
            
    }

	/**
     * Get the value map which contains the values of the input message. 
     * This can be get by JSF pages. 
     * 
     * @return the value map which contains the values of the input message
     */
    public HashMap getInputValues() {
        return inputValues;
    }
       
    /**
     * Get the value map which contains the values for the output message.
     * This can be get by JSF pages.
     * 
     * @return the value map which contains the values for the output message
     */
    public HashMap getOutputValues() {
        return outputValues;
    }
    
    /**
     * Get the values for the output message.
     * If passed <param>dataType</param> is an instance of DataObject the return value will also be of this type.
     * Otherwise the data primitive of output mapped to key SINGLE_PRIMITIVE_TYPE is returned. 
     *  
     * @param dataType the structure (may be empty) of the data to get
     * @return the values / the value of the output message
     * @throws PropertyPopulationException 
     *      		This exception will be thrown if the outputValues of this ToDoInstance does not match the 
     * 				expected Service Data Object.
     * @throws PropertyNotFoundException 
     *      		This exception will be thrown if the outputValues of this ToDoInstance does not match the 
     * 				expected Service Data Object.
     */
    public Object getOutputValues(Object dataType) throws PropertyNotFoundException, PropertyPopulationException {
    	Object ret = null;

		if (outputValues != null) {
			if (dataType instanceof DataObject) {
				ret = DataObjectUtils.populateAll((DataObject) dataType, outputValues);
			} else {
				ret = outputValues.get(SINGLE_PRIMITIVE_TYPE);
			}
		}
		return ret; 
    }
       
    /**
	 * Set the values for the input message. If passed <param>inputData</param>
	 * is an instance of DataObject or HashMap all values will be set to this ToDoInstance. 
	 * Otherwise passed <param>inputData</param> will be mapped to input using key SINGLE_PRIMITIVE_TYPE.
	 * 
	 * @param inputValues the values for the input message
	 */
    public void setInputValues(Object inputData) {
    	
    	if (inputData == null) {
			this.inputValues = null;
		} else if (inputData instanceof DataObject) {
			this.inputValues = (HashMap) DataObjectUtils.getValueMap((DataObject) inputData);
		} else if (inputData instanceof HashMap) {
			this.inputValues = (HashMap) inputData;
		} else {
			this.inputValues = new HashMap();
			this.inputValues.put(SINGLE_PRIMITIVE_TYPE, inputData);
		}        
    }
    
    /**
     * Set the values for the output message.
     * If passed <param>outputData</param> is an instance of DataObject or HashMap all
     * values will be set to this ToDoInstance. 
     * Otherwise passed <param>outputData</param> will be mapped using key SINGLE_PRIMITIVE_TYPE.
     * 
     * @param outputValues the values for the output message
     */
    public void setOutputValues(Object outputData) {
    	
    	if (outputData == null) {
			this.outputValues = null;
		} else if (outputData instanceof DataObject) {
			this.outputValues = (HashMap) DataObjectUtils.getValueMap((DataObject) outputData);
		} else if (outputData instanceof HashMap) {
			this.outputValues = (HashMap) outputData;
		} else {
			this.outputValues = new HashMap();
			this.outputValues.put(SINGLE_PRIMITIVE_TYPE, outputData);
		}        
    }   
   
}
