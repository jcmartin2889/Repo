/*
*
* Sample program for use with the Product
* Licensed Materials  - Property of IBM
* 5724-I66
* (c) Copyright IBM Corp.  2006, 2009
*   
*/
package com.ibm.wbit.tel.client.jsf.infrastructure;

import com.ibm.bpc.clientcore.ClientException;
import com.ibm.bpc.clientcore.exception.CommandBarMessage;

/**
 * To show a Client Exception in command bar we have to implement interface CommandBarMessage
 */
public class CommandException extends ClientException implements CommandBarMessage {
	
	private static final long serialVersionUID = 602L;

    /**
     * CommandException to show Client Exception in command bar
     * 
     * @param catalog - The catalog to be used to retrieve the message.
     * @param key - The message key.
     * @param vars - The message variables. May be null.
     * @param cause - The exception that was thrown.
     */
    public CommandException(String catalog, String key, Object[] vars, Throwable cause) {
        super(catalog, key, vars, cause);
    }
}
