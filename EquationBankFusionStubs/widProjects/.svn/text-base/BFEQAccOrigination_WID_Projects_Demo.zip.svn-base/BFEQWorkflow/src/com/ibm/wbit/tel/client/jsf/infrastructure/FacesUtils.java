/*
 *
 * Sample program for use with the Product
 * Licensed Materials  - Property of IBM
 * 5724-I66
 * (c) Copyright IBM Corp.  2006, 2009
 *   
 */
package com.ibm.wbit.tel.client.jsf.infrastructure;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;

import com.ibm.bpc.clientcore.ClientException;
import com.ibm.bpc.clientcore.DataObjectUtils;
import com.ibm.bpc.clientcore.MessageWrapper;
import com.ibm.wbit.tel.client.jsf.bean.ToDoInstance;
import commonj.sdo.DataObject;
import com.ibm.wbit.tel.client.jsf.handler.ToDoMessageHandler;

/**
 * This class provides some general utilities, usefully in the context of JSF and this Business User Client.
 */
public class FacesUtils implements SharedConstants {

  
	/**
     * Get the external context of faces application.
     * 
     * @return external context of faces application
     */
    public static ExternalContext getContext() {
        FacesContext facesContext = FacesContext.getCurrentInstance();

        return (facesContext == null) ? null : facesContext.getExternalContext();
    }

    
    /**
     * Return the locale of the request.
     * 
     * @return the locale
     */
    public static Locale getLocale() {
        Locale locale = null;

        if (getContext() != null) {
            locale = getContext().getRequestLocale();
        }

        if (locale == null) {
            locale = new Locale("en", "us");
        }

        return locale;
    }

    
    /**
     * Get managed bean instance for passed name. 
     * The passed name must be defined in faces-config as <managed-bean-name>
     * 
     * @param managedBeanName
     *            as of <managed-bean-name></managed-bean-name> in faces-config.
     * @return managed bean instance for passed name
     */
    public static Object getManagedBeanInstance(String managedBeanName) {

        String name = "#{" + managedBeanName + "}";

        ValueBinding vb = FacesContext.getCurrentInstance().getApplication().createValueBinding(name);

        return vb.getValue(FacesContext.getCurrentInstance());
    }
    

	/**
	 * The ID which makes human tasks unique for template based approach.
	 * 
	 * @param toDoInstance for which to get the unique ID
	 * @return ID which makes human tasks unique for template based approach.
	 */
    public static String getHumanTaskID(ToDoInstance toDoInstance) {
    	
    	return toDoInstance.getDefinitionNamespace() + toDoInstance.getDefinitionName();
    }
    
    
    /**
     * Get input values of passed toDoInstance as HashMap.
     * 
     * @param toDoInstance for which to get the input values
     * @return HashMap populated with input values (API result of query) of passed toDoInstance
     */
    public static HashMap getInputMessage(ToDoInstance toDoInstance) throws ClientException {
    	HashMap ret = null;

		if (toDoInstance != null) {
			Object object = toDoInstance.getInputMessageWrapper().getMessage();
			if (object instanceof DataObject) {
				ret = (HashMap) DataObjectUtils.getValueMap((DataObject) object);
			} else {
				ret = new HashMap();
				ret.put(SINGLE_PRIMITIVE_TYPE, object);
			}
		}
		return ret; 
    }
    
    /**
     * Get output values of passed toDoInstance as HashMap.
     * 
     * @param toDoInstance for which to get the output values
     * @return HashMap populated with output values (API result of query) of passed toDoInstance
     */
    public static HashMap getOutputMessage(ToDoInstance toDoInstance) throws ClientException {
		HashMap ret = null;

		if ((toDoInstance != null) && (toDoInstance.getOutputMessageTypeName() != null)) {
			MessageWrapper outputMessage = toDoInstance.getOutputMessageWrapper();
			// does outputmessage contain values?
			if (outputMessage != null && outputMessage.getMessage() != null) {
				Object object = outputMessage.getMessage();
				if (object instanceof DataObject) {
					ret = (HashMap) DataObjectUtils.getValueMap((DataObject) object);
				} else {
					ret = new HashMap();
					ret.put(SINGLE_PRIMITIVE_TYPE, object);
				}
			}
		}
		return ret;
	}
    
    /**
     * Get HashMap pre-populated with values from input messsage of toDoInstance.
     * If pre-population is not possible, due to different definition 
     * of input- and output message, null is returned.
	 *   
     * @param toDoInstance from which to get the input values
     * @return HashMap populated with values of toDoInstances input message 
     * and keys suitable for output messsage, or null if pre-population not possible.
     */
    public static HashMap getValueMapInOut(ToDoInstance toDoInstance) throws ClientException {
    	
    	//check if input and output-message use same Businesss Objects   
    	HashMap inEqualsOut = (HashMap) getManagedBeanInstance("toDosInEqualsOut");
    	return getValueMap(getInputMessage(toDoInstance), getHumanTaskID(toDoInstance), inEqualsOut);
    }
    
    
    /**
     * Get HashMap pre-populated with values from passed soruceValues.
     * The passed humanTaskID is used to get the prefixes for the keys in returned HashMap. 
     * If pre-population is not possible, due to different definition 
     * of output- and input message, null is returned.
	 *   
	 * @param sourceValues used to populate return HashMap
	 * @param humanTaskID to identify the task according to template based approach
     * @return HashMap populated with values of passed soruceValues 
     * and keys suitable for input messsage, or null if pre-population not possible.
     */
    public static HashMap getValueMapOutIn(HashMap sourceValues, String humanTaskID) throws ClientException {
    	
    	//check if output and input-message use same Businesss Objects   
    	HashMap outEqualsIn = (HashMap) getManagedBeanInstance("toDosOutEqualsIn");
    	return getValueMap(sourceValues, humanTaskID, outEqualsIn);
    }
    
    
    /**
	 * Get HashMap pre-populated with values from input messsage of mainToDo. 
	 * If pre-population MainIn->SubIn is not possible, null is returned.
	 * 
	 * @param subToDoID for which to get pre-populated HashMap
	 * @param mainToDo from which to get the pre-population values
	 * @return HashMap populated with values of mainToDo input message 
     * and keys suitable for subToDo input messsage, or null if pre-population not possible.
	 */
    public static HashMap getValueMapMainInSubIn(String subToDoID, ToDoInstance mainToDo) throws ClientException {
    	HashMap ret = null;

		// check if subToDo and mainToDo are of same type
		if (subToDoID.equals(FacesUtils.getHumanTaskID(mainToDo))) {
			// pre-population works anyway
			ret = getInputMessage(mainToDo);
		} else {
			// check if subToDo and mainToDo use same Businesss Objects regarding input message
			HashMap mainInSubIn;
			mainInSubIn = (HashMap) getManagedBeanInstance("toDosMainInEqualsSubIn");
			ret = getValueMap(getInputMessage(mainToDo), getHumanTaskID(mainToDo) + subToDoID, mainInSubIn);
		}
		return ret;
    }
    
    
    /**
     * Get HashMap pre-populated with values from output messsage of subToDo.
     * Finished state of subToDo is not required by this method. 
     * If pre population SubOut->MainOut is not possible, null is returned.
     *  
     * @param subToDo from which to get the pre-population values	
     * @param mainToDo whose output message should be pre-populated
     * @return HashMap populated with values of subToDo output message 
     * and keys suitable for mainToDo output messsage, or null if pre-population not possible.
     */
    public static HashMap getValueMapSubOutMainOut(ToDoInstance subToDo, ToDoInstance mainToDo) throws ClientException {
		HashMap ret = null;

		// outputmessage defined?
		if (mainToDo.getOutputMessageTypeName() != null) {
			// check if subToDo and mainToDo are of same type
			if (getHumanTaskID(subToDo).equals(getHumanTaskID(mainToDo))) {
				// pre-population works anyway
				ret = getOutputMessage(subToDo);
			} else {
				// check if subToDo and mainToDo use same Business Objects regarding output message
				HashMap subOutMainOut;
				subOutMainOut = (HashMap) getManagedBeanInstance("toDosSubOutEqualsMainOut");
				ret = getValueMap(getOutputMessage(subToDo), getHumanTaskID(subToDo) + getHumanTaskID(mainToDo), 
						subOutMainOut);
			}
		}
		return ret;
	}   
    
    
    /**
	 * Get HashMap populated with values of passed sourceValues. The key prefixes
	 * in returned HashMap come for passed prefixMappings.
	 * If pre population is not possible, null is returned. 
	 * 
	 * @param sourceValues used to populate return HashMap
	 * @param prefixMappingKey prefix for key in passed HashMap prefixMappings
	 * @param prefixMappings to get the key prefixes for return HashMap
	 * @return HashMap populated with values from sourceValues and keys according to passed prefixMappings
	 */
    private static HashMap getValueMap(HashMap sourceValues, String prefixMappingKey, HashMap prefixMappings) {
    	
		HashMap ret = null;
		boolean mappingFailed = false;
		
		if ((sourceValues != null) && (prefixMappings != null)) {
			Iterator anIterator = sourceValues.keySet().iterator();
			String prefixSrc, prefixTgt, keySrc, keyTgt;
			Object value;
			int idx;
			//we have to "copy" all values and to change the key
			while (anIterator.hasNext() && !mappingFailed) {
				keySrc = (String) anIterator.next();
				value = sourceValues.get(keySrc);
				idx = keySrc.indexOf("/", 1);
				// wrapper element complex data type (BusinessObject) ?
				if (idx != -1) {
					prefixSrc = keySrc.substring(1, idx);
				} else {
					prefixSrc = keySrc.substring(1);
				}
				// get prefix for target mapping
				prefixTgt = (String) prefixMappings.get(prefixMappingKey + prefixSrc);

				if (prefixTgt != null) {
					keyTgt = "/" + prefixTgt;
					// wrapper element complex data type (BusinessObject) ?
					if (idx != -1) {
						keyTgt = keyTgt + keySrc.substring(idx);
					}
					if (ret == null) {
						ret = new HashMap((int) (sourceValues.size() * 1.4f + 0.5f));
					}
					ret.put(keyTgt, value);
				} else {
					mappingFailed = true;
				}
			}
		}
		return mappingFailed ? null : ret;
	}
    
    /**
     * Returns true if the inout and output message for the todomessage handler are equal.
     * They are equal if the can be replaced or if the refer to the same message.
     * 
     * @param toDoMessageHandler The ToDoMessage handler to check.
     * @return true if the inout and outputmessage are equal, otherwise false.
     */
    public static boolean isInputEqualsOutput(ToDoMessageHandler toDoMessageHandler) throws ClientException{
    	
		boolean isReplaceable = FacesUtils.getValueMapInOut(toDoMessageHandler.getToDoInstance()) != null;
		String inputMessageName = toDoMessageHandler.getToDoInstance().getInputMessageTypeName();
		String outputMessage = toDoMessageHandler.getToDoInstance().getOutputMessageTypeName();
		boolean isMessageNameEqual = inputMessageName.equals(outputMessage);
		
		return isReplaceable || isMessageNameEqual;
    }
    
        
}
